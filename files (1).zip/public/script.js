document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("soinForm");

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const data = {
      nom: form.nom.value,
      tel: form.tel.value,
      adresse: form.adresse.value,
      soin: form.soin.value,
      description: form.description.value
    };

    const res = await fetch("/api/demandes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    if (res.ok) {
      alert("✅ Demande envoyée !");
      form.reset();
      chargerDemandes();
    } else {
      alert("❌ Erreur d’envoi.");
    }
  });

  // Fonction pour charger et afficher les demandes
  async function chargerDemandes() {
    const res = await fetch("/api/demandes");
    const demandes = await res.json();
    const tbody = document.querySelector("#demandesTable tbody");
    tbody.innerHTML = "";
    demandes.forEach(demande => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${demande.nom}</td>
        <td>${demande.tel}</td>
        <td>${demande.adresse}</td>
        <td>${demande.soin}</td>
        <td>${demande.description}</td>
        <td>${demande.statut}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  // Charger les demandes au chargement de la page
  chargerDemandes();
});