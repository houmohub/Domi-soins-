import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

export async function getDBConnection() {
  return open({
    filename: './soins.db',
    driver: sqlite3.Database
  });
}

export async function initDB() {
  const db = await getDBConnection();
  await db.exec(`
    CREATE TABLE IF NOT EXISTS demandes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nom TEXT,
      tel TEXT,
      adresse TEXT,
      soin TEXT,
      description TEXT,
      statut TEXT DEFAULT 'reçu'
    )
  `);
}