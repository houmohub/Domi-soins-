import express from 'express';
import cors from 'cors';
import { getDBConnection, initDB } from './database.js';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const PORT = process.env.PORT || 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

await initDB();

app.post('/api/demandes', async (req, res) => {
  const { nom, tel, adresse, soin, description } = req.body;
  const db = await getDBConnection();
  await db.run(
    'INSERT INTO demandes (nom, tel, adresse, soin, description) VALUES (?, ?, ?, ?, ?)',
    [nom, tel, adresse, soin, description]
  );
  res.status(201).json({ message: 'Demande enregistrée' });
});

app.get('/api/demandes', async (req, res) => {
  const db = await getDBConnection();
  const demandes = await db.all('SELECT * FROM demandes');
  res.json(demandes);
});

app.listen(PORT, () => {
  console.log(`✅ Serveur prêt sur http://localhost:${PORT}`);
});